Page({
  data: {
    lists: [
      {
        url: '../normal/normal',
        name: '常规'
      },
      {
        url: '../avatarUpload/index/index',
        name: '头像上传'
      },
      {
        url: '../network/network',
        name: '裁剪网络图'
      },
      {
        url: '../watermark/watermark',
        name: '图片加水印'
      },
      {
        url: '../cutInside/cutInside',
        name: '局部裁剪'
      }
    ]
  }
})
